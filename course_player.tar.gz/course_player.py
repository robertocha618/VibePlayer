#!/usr/bin/env python3
"""
Course Player - A Local Video Course Platform with Advanced Controls
Recursively scans for video files and serves them with an interactive LMS-style player.
"""

import os
import json
import re
import http.server
import socketserver
import webbrowser
import threading
from pathlib import Path
from urllib.parse import quote, unquote, parse_qs, urlparse

# Configuration
PORT = 8000
VIDEO_EXTENSIONS = ('.mp4', '.mkv', '.webm')
SUBTITLE_EXTENSIONS = ('.srt', '.vtt')
PROGRESS_FILE = 'progress.json'

def natural_sort_key(s):
    """
    Sort strings naturally (e.g., '2' before '10').
    """
    return [int(text) if text.isdigit() else text.lower()
            for text in re.split(r'(\d+)', str(s))]

def load_progress():
    """
    Load the list of watched video paths from progress.json.
    Returns a list of paths (strings).
    """
    if not os.path.exists(PROGRESS_FILE):
        return []
    
    try:
        with open(PROGRESS_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('watched', [])
    except Exception as e:
        print(f"Error loading progress: {e}")
        return []

def save_progress(video_path):
    """
    Add a video path to the watched list and save to progress.json.
    """
    watched = load_progress()
    
    # Normalize path for comparison
    normalized_path = video_path.replace('\\', '/')
    
    if normalized_path not in watched:
        watched.append(normalized_path)
        
        try:
            with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
                json.dump({'watched': watched}, f, indent=2)
            print(f"✓ Marked as watched: {video_path}")
        except Exception as e:
            print(f"Error saving progress: {e}")

def remove_progress(video_path):
    """
    Remove a video path from the watched list and save to progress.json.
    """
    watched = load_progress()
    
    # Normalize path for comparison
    normalized_path = video_path.replace('\\', '/')
    
    if normalized_path in watched:
        watched.remove(normalized_path)
        
        try:
            with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
                json.dump({'watched': watched}, f, indent=2)
            print(f"✗ Unmarked: {video_path}")
        except Exception as e:
            print(f"Error removing progress: {e}")

def reset_progress():
    """
    Clear all progress by deleting or emptying progress.json.
    """
    try:
        with open(PROGRESS_FILE, 'w', encoding='utf-8') as f:
            json.dump({'watched': []}, f, indent=2)
        print("🔄 Progress reset")
    except Exception as e:
        print(f"Error resetting progress: {e}")

def find_subtitle_for_video(video_path, dirpath):
    """
    Find matching subtitle file for a video.
    Returns relative path to subtitle or None.
    """
    video_name = os.path.splitext(os.path.basename(video_path))[0]

    for ext in SUBTITLE_EXTENSIONS:
        subtitle_name = video_name + ext
        subtitle_path = os.path.join(dirpath, subtitle_name)
        if os.path.exists(subtitle_path):
            return subtitle_name

    return None

def srt_to_vtt(srt_content):
    """
    Convert SRT subtitle format to WebVTT format.
    """
    # Add WebVTT header
    vtt_content = "WEBVTT\n\n"

    # Replace comma with period in timestamps (SRT uses comma, VTT uses period)
    vtt_content += re.sub(r'(\d{2}:\d{2}:\d{2}),(\d{3})', r'\1.\2', srt_content)

    return vtt_content

def scan_videos(root_dir):
    """
    Recursively scan for video files and organize by TOP-LEVEL folders only.
    
    GROUPING LOGIC:
    - Each immediate subdirectory of root becomes a Section
    - Files in root are grouped under "General" section
    
    RECURSIVE COLLECTION:
    - Inside each top-level section, recursively find all videos regardless of depth
    
    SMART NAMING (Context Preservation):
    - Video display names include parent folder context (excluding section name)
    - Example: SECTION 10.../Module 2.../1. Security.../Video.mp4
      Display: "Module 2 - 1. Security - Video"
    - Uses " - " as separator
    
    SORTING:
    - Sections sorted naturally
    - Videos within a section sorted by FULL FILE PATH (not just filename)
      This ensures Module 1 videos appear before Module 2 videos
    
    Returns a dictionary with sections and their videos.
    """
    course_structure = {}
    root_path = Path(root_dir)
    
    # First, collect videos from root directory (not in any folder)
    root_videos = []
    root_resources = []
    
    for item in root_path.iterdir():
        if item.is_file():
            filename = item.name
            if filename.lower().endswith(VIDEO_EXTENSIONS):
                # Find matching subtitle
                subtitle = find_subtitle_for_video(filename, root_dir)
                
                root_videos.append({
                    'name': item.stem,  # Remove extension
                    'path': filename,
                    'full_path': filename,  # For sorting
                    'subtitle': subtitle if subtitle else None,
                    'resources': []  # Root videos have no resources
                })
            elif (not filename.lower().endswith(SUBTITLE_EXTENSIONS) and
                  not filename.startswith('.') and
                  filename not in ['index.html', 'progress.json', 'course_player.py', 'course_player_copy.py']):
                root_resources.append({
                    'name': filename,
                    'path': filename
                })
    
    # Add root videos to "General" section if any exist
    if root_videos:
        root_videos.sort(key=lambda x: natural_sort_key(x['full_path']))
        root_resources.sort(key=lambda x: natural_sort_key(x['name']))
        # Remove full_path before storing
        for vid in root_videos:
            vid.pop('full_path', None)
        course_structure['00-General'] = {
            'path': '.',
            'videos': root_videos
        }
    
    # Get only TOP-LEVEL directories (immediate subdirectories of root)
    top_level_dirs = [d for d in root_path.iterdir() if d.is_dir() and d.name != 'client' and d.name != '__pycache__' and not d.name.startswith('.')]
    top_level_dirs.sort(key=lambda x: natural_sort_key(x.name))
    
    # Process each top-level section
    for top_dir in top_level_dirs:
        section_name = top_dir.name
        section_videos = []
        
        # Recursively walk through this top-level directory and ALL its subfolders
        for dirpath, dirnames, filenames in os.walk(str(top_dir)):
            current_dir = Path(dirpath)
            
            # Get relative path from top-level section folder (excludes section name)
            rel_from_section = current_dir.relative_to(top_dir)
            
            # Get relative path from root (includes section name) - for full path sorting
            rel_from_root = current_dir.relative_to(root_path)
            
            # Find video files in current directory
            video_files = [f for f in filenames if f.lower().endswith(VIDEO_EXTENSIONS)]
            
            if video_files:
                # Find resource files in this directory
                resource_files = []
                for f in filenames:
                    f_lower = f.lower()
                    if (not f_lower.endswith(VIDEO_EXTENSIONS) and
                        not f_lower.endswith(SUBTITLE_EXTENSIONS) and
                        not f.startswith('.') and
                        f != 'index.html'):
                        # Path relative to root
                        resource_rel_path = current_dir.relative_to(root_path) / f
                        resource_files.append({
                            'name': f,
                            'path': str(resource_rel_path).replace('\\', '/')
                        })
                
                resource_files.sort(key=lambda x: natural_sort_key(x['name']))
                
                # Process each video
                for video in video_files:
                    video_stem = Path(video).stem
                    
                    # Build display name with SMART context (parent folders, excluding section name)
                    if str(rel_from_section) != '.':
                        # Get path parts
                        subfolder_parts = str(rel_from_section).replace('\\', '/').split('/')
                        
                        # Smart context extraction: Look for "Module" folders
                        # If we find a folder starting with "Module", only show context from there
                        module_start_idx = None
                        for idx, part in enumerate(subfolder_parts):
                            if part.lower().startswith('module'):
                                module_start_idx = idx
                                break
                        
                        # Use context from Module onwards, or all if no Module found
                        if module_start_idx is not None:
                            context_parts = subfolder_parts[module_start_idx:]
                        else:
                            context_parts = subfolder_parts
                        
                        # Join with " - " separator
                        context_prefix = ' - '.join(context_parts)
                        video_display_name = f"{context_prefix} - {video_stem}"
                    else:
                        # Video is directly in the top-level section folder
                        video_display_name = video_stem
                    
                    # Full path relative to root (for storage and sorting)
                    video_rel_path = rel_from_root / video
                    video_full_path_str = str(video_rel_path).replace('\\', '/')
                    
                    # Find matching subtitle
                    subtitle = find_subtitle_for_video(video, str(current_dir))
                    subtitle_path = None
                    if subtitle:
                        subtitle_rel_path = current_dir.relative_to(root_path) / subtitle
                        subtitle_path = str(subtitle_rel_path).replace('\\', '/')
                    
                    section_videos.append({
                        'name': video_display_name,
                        'path': video_full_path_str,
                        'full_path': video_full_path_str,  # For sorting by full path
                        'subtitle': subtitle_path,
                        'resources': resource_files
                    })
        
        # CRUCIAL: Sort videos by FULL FILE PATH (not just display name)
        # This ensures proper ordering: Module 1 before Module 2, etc.
        section_videos.sort(key=lambda x: natural_sort_key(x['full_path']))
        
        # Remove the temporary full_path field before storing
        for vid in section_videos:
            vid.pop('full_path', None)
        
        # Add section to course structure if it has videos
        if section_videos:
            course_structure[section_name] = {
                'path': str(top_dir.relative_to(root_path)).replace('\\', '/'),
                'videos': section_videos
            }
    
    # Sort sections naturally by section name
    sorted_sections = sorted(course_structure.items(), key=lambda x: natural_sort_key(x[0]))
    return dict(sorted_sections)

class CourseHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """
    Custom HTTP request handler to serve video files, handle subtitle conversion,
    and manage progress tracking API endpoints.
    """
    def serve_static_file(self, file_path, content_type):
        if not os.path.exists(file_path):
            self.send_error(404, f"File not found: {file_path}")
            return
        
        try:
            with open(file_path, 'rb') as f:
                content = f.read()
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', len(content))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Internal server error: {e}")

    def serve_json(self, data):
        try:
            content = json.dumps(data).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', len(content))
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self.send_error(500, f"Internal server error: {e}")

    def do_GET(self):
        # Parse the URL
        parsed_path = urlparse(self.path)
        path = unquote(parsed_path.path.lstrip('/'))

        # API Endpoints
        if path == 'api/course_structure':
            current_dir = os.getcwd()
            course_name = os.path.basename(current_dir)
            course_structure = scan_videos(current_dir)
            self.serve_json({
                'course_name': course_name,
                'structure': course_structure
            })
            return

        elif path == 'api/progress':
            watched = load_progress()
            self.serve_json(watched)
            return

        # Static Assets
        elif path == '' or path == 'index.html':
            self.serve_static_file('client/index.html', 'text/html; charset=utf-8')
            return

        elif path == 'styles.css':
            self.serve_static_file('client/styles.css', 'text/css; charset=utf-8')
            return

        elif path == 'app.js':
            self.serve_static_file('client/app.js', 'application/javascript; charset=utf-8')
            return

        # Check if it's a subtitle file
        elif path.lower().endswith('.srt'):
            # Convert SRT to VTT on the fly
            file_path = os.path.join(os.getcwd(), path)
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        srt_content = f.read()

                    vtt_content = srt_to_vtt(srt_content)

                    self.send_response(200)
                    self.send_header('Content-Type', 'text/vtt; charset=utf-8')
                    self.send_header('Content-Length', len(vtt_content.encode('utf-8')))
                    self.end_headers()
                    self.wfile.write(vtt_content.encode('utf-8'))
                    return
                except Exception as e:
                    print(f"Error converting SRT to VTT: {e}")

        # Default behavior for other files
        super().do_GET()
    
    def do_POST(self):
        """
        Handle POST requests for progress tracking API.
        """
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Get content length and read body
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8') if content_length > 0 else '{}'
        
        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            self.send_error(400, "Invalid JSON")
            return
        
        # API: Mark video as watched
        if path == '/api/mark_watched':
            video_path = data.get('path', '')
            if video_path:
                save_progress(video_path)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                response = json.dumps({'success': True, 'path': video_path})
                self.wfile.write(response.encode('utf-8'))
            else:
                self.send_error(400, "Missing 'path' parameter")
        
        # API: Toggle watched status
        elif path == '/api/toggle_watched':
            video_path = data.get('path', '')
            if video_path:
                watched = load_progress()
                normalized_path = video_path.replace('\\', '/')
                
                if normalized_path in watched:
                    remove_progress(video_path)
                    is_watched = False
                else:
                    save_progress(video_path)
                    is_watched = True
                
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                response = json.dumps({'success': True, 'watched': is_watched, 'path': video_path})
                self.wfile.write(response.encode('utf-8'))
            else:
                self.send_error(400, "Missing 'path' parameter")
        
        # API: Reset all progress
        elif path == '/api/reset_progress':
            reset_progress()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = json.dumps({'success': True})
            self.wfile.write(response.encode('utf-8'))
        
        else:
            self.send_error(404, "API endpoint not found")

    def end_headers(self):
        # Add headers to support video streaming and CORS
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def log_message(self, format, *args):
        # Custom logging
        if not self.path.endswith('.ico'):  # Skip favicon requests in logs
            print(f"[{self.log_date_time_string()}] {format % args}")

def start_server():
    """
    Start the HTTP server and open browser.
    """
    handler = CourseHTTPRequestHandler

    with socketserver.TCPServer(("", PORT), handler) as httpd:
        print(f"\n{'='*60}")
        print(f"🎓 Course Player Server Started")
        print(f"{'='*60}")
        print(f"📂 Serving from: {os.getcwd()}")
        print(f"🌐 URL: http://localhost:{PORT}")
        print(f"{'='*60}\n")
        print("Press Ctrl+C to stop the server\n")

        # Open browser
        webbrowser.open(f'http://localhost:{PORT}')

        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n\n🛑 Server stopped by user")
            print("Goodbye! 👋\n")

def main():
    """
    Main function to orchestrate the course player.
    """
    print("\n🔍 Scanning for video files and subtitles...")

    # Scan current directory for videos
    current_dir = os.getcwd()

    # Get the course name from the current directory
    course_name = os.path.basename(current_dir)

    course_structure = scan_videos(current_dir)

    if not course_structure:
        print("\n❌ No video files found!")
        print("   Supported formats: .mp4, .mkv, .webm")
        print("   Please run this script in a directory containing video files.\n")
        return

    # Count total sections, videos, and subtitles
    total_sections = len(course_structure)
    total_videos = sum(len(section['videos']) for section in course_structure.values())
    total_subtitles = sum(1 for section in course_structure.values()
                         for video in section['videos'] if video['subtitle'])

    print(f"📚 Course: {course_name}")
    print(f"✅ Found {total_videos} videos in {total_sections} sections")
    if total_subtitles > 0:
        print(f"📝 Found {total_subtitles} subtitle files\n")
    else:
        print()

    # Start server
    print("🚀 Starting web server...")
    start_server()

if __name__ == '__main__':
    main()
