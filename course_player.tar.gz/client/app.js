// State variables
let courseData = {};
let watchedVideos = [];
let currentVideo = null;
let currentSection = null;
let videoList = [];
let isDraggingProgress = false;
let isFullscreen = false;
let isResizing = false;
let startX = 0;
let startWidth = 0;
let inactivityTimer = null;
let isControlsVisible = true;
let subtitleSize = localStorage.getItem('subtitleSize') || '100%';
let subtitleFontColor = localStorage.getItem('subtitleFontColor') || 'White';
let subtitleFontOpacity = localStorage.getItem('subtitleFontOpacity') || '100%';
let subtitleBgColor = localStorage.getItem('subtitleBgColor') || 'Black';
let subtitleBgOpacity = localStorage.getItem('subtitleBgOpacity') || '75%';
let subtitleEdgeStyle = localStorage.getItem('subtitleEdgeStyle') || 'None';
let subtitlesEnabled = false;

// Subtitle Color RGB Lookup Map
const subtitleColorMap = {
    'White': [255, 255, 255],
    'Yellow': [255, 255, 0],
    'Green': [0, 255, 0],
    'Cyan': [0, 255, 255],
    'Blue': [0, 0, 255],
    'Red': [255, 0, 0],
    'Magenta': [255, 0, 255],
    'Black': [0, 0, 0]
};

// DOM Elements
const sidebar = document.getElementById('sidebar');
const resizer = document.getElementById('resizer');
const sectionsContainer = document.getElementById('sections-container');
const videoContainer = document.getElementById('video-container');
const videoPlayer = document.getElementById('video-player');
const welcomeScreen = document.getElementById('welcome-screen');
const videoInfo = document.getElementById('video-info');
const videoTitle = document.getElementById('video-title');
const videoSection = document.getElementById('video-section');
const videoControls = document.getElementById('video-controls');
const playPauseBtn = document.getElementById('play-pause-btn');
const playIcon = document.getElementById('play-icon');
const pauseIcon = document.getElementById('pause-icon');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const volumeBtn = document.getElementById('volume-btn');
const volumeIcon = document.getElementById('volume-icon');
const muteIcon = document.getElementById('mute-icon');
const volumeSlider = document.getElementById('volume-slider');
const ccBtn = document.getElementById('cc-btn');
const ccDropdown = document.getElementById('cc-dropdown');
const ccToggle = document.getElementById('cc-toggle');
const ccLoad = document.getElementById('cc-load');
const subtitleFileInput = document.getElementById('subtitle-file-input');
const settingsBtn = document.getElementById('settings-btn');
const settingsDropdown = document.getElementById('settings-dropdown');
const fullscreenBtn = document.getElementById('fullscreen-btn');
const fullscreenIcon = document.getElementById('fullscreen-icon');
const fullscreenExitIcon = document.getElementById('fullscreen-exit-icon');
const speedToast = document.getElementById('speed-toast');
const timeDisplay = document.getElementById('time-display');
const progressContainer = document.getElementById('progress-container');
const progressBar = document.getElementById('progress-bar');
const progressTooltip = document.getElementById('progress-tooltip');
const loadingSpinner = document.getElementById('loading-spinner');
const subtitleTrack = document.getElementById('subtitle-track');
const subtitleOverlay = document.getElementById('subtitle-overlay');
const resourcesBtn = document.getElementById('resources-btn');
const resourcesPanel = document.getElementById('resources-panel');
const resourcesList = document.getElementById('resources-list');
const resetProgressBtn = document.getElementById('reset-progress-btn');

// Build flat list of all videos for navigation
function buildVideoList() {
    videoList = [];
    Object.entries(courseData).forEach(([sectionName, sectionData]) => {
        sectionData.videos.forEach(video => {
            videoList.push({
                section: sectionName,
                video: video
            });
        });
    });
}

// Mark video as watched (server-side)
async function markAsWatched(videoPath) {
    try {
        const response = await fetch('/api/mark_watched', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: videoPath })
        });
        
        if (response.ok) {
            if (!watchedVideos.includes(videoPath)) {
                watchedVideos.push(videoPath);
                updateSidebarCheckmarks();
                updateStats();
            }
        }
    } catch (error) {
        console.error('Error marking video as watched:', error);
    }
}

// Toggle watched status (server-side)
async function toggleWatched(videoPath) {
    try {
        const response = await fetch('/api/toggle_watched', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: videoPath })
        });
        
        if (response.ok) {
            const data = await response.json();
            
            if (data.watched) {
                if (!watchedVideos.includes(videoPath)) {
                    watchedVideos.push(videoPath);
                }
            } else {
                watchedVideos = watchedVideos.filter(p => p !== videoPath);
            }
            
            updateSidebarCheckmarks();
            updateStats();
        }
    } catch (error) {
        console.error('Error toggling watched status:', error);
    }
}

// Reset all progress (server-side)
async function resetProgress() {
    if (!confirm('Are you sure you want to reset all progress? This cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch('/api/reset_progress', {
            method: 'POST'
        });
        
        if (response.ok) {
            watchedVideos = [];
            updateSidebarCheckmarks();
            updateStats();
        }
    } catch (error) {
        console.error('Error resetting progress:', error);
    }
}

// Update checkmarks in sidebar
function updateSidebarCheckmarks() {
    document.querySelectorAll('.video-item').forEach(item => {
        const videoPath = item.dataset.path;
        const isWatched = watchedVideos.includes(videoPath);
        
        if (isWatched) {
            item.classList.add('watched');
        } else {
            item.classList.remove('watched');
        }
        
        const checkmark = item.querySelector('.video-checkmark');
        if (checkmark) {
            checkmark.textContent = isWatched ? '✓' : '';
        }
    });
    
    document.querySelectorAll('.section').forEach(section => {
        const sectionHeader = section.querySelector('.section-header');
        const sectionTitle = sectionHeader.querySelector('.section-title');
        const videoItems = section.querySelectorAll('.video-item');
        
        const totalVideos = videoItems.length;
        const watchedCount = Array.from(videoItems).filter(item => 
            watchedVideos.includes(item.dataset.path)
        ).length;
        const isComplete = watchedCount === totalVideos && totalVideos > 0;
        
        const oldProgress = sectionTitle.querySelector('.section-progress');
        if (oldProgress) {
            oldProgress.remove();
        }
        
        const progressSpan = document.createElement('span');
        progressSpan.className = `section-progress ${isComplete ? 'completed' : 'in-progress'}`;
        
        if (isComplete) {
            progressSpan.innerHTML = `<span class="checkmark">✓</span>${watchedCount}/${totalVideos}`;
        } else {
            progressSpan.textContent = `${watchedCount}/${totalVideos}`;
        }
        
        sectionTitle.appendChild(progressSpan);
        
        if (isComplete) {
            sectionHeader.classList.add('completed');
        } else {
            sectionHeader.classList.remove('completed');
        }
    });
}

// Render sidebar sections
function renderSidebar() {
    sectionsContainer.innerHTML = '';

    Object.entries(courseData).forEach(([sectionName, sectionData]) => {
        const section = document.createElement('div');
        section.className = 'section';

        const totalVideos = sectionData.videos.length;
        const watchedCount = sectionData.videos.filter(v => watchedVideos.includes(v.path)).length;
        const isComplete = watchedCount === totalVideos && totalVideos > 0;
        
        let progressHTML = '';
        if (isComplete) {
            progressHTML = `<span class="section-progress completed"><span class="checkmark">✓</span>${watchedCount}/${totalVideos}</span>`;
        } else if (watchedCount > 0) {
            progressHTML = `<span class="section-progress in-progress">${watchedCount}/${totalVideos}</span>`;
        } else {
            progressHTML = `<span class="section-progress in-progress">0/${totalVideos}</span>`;
        }

        const header = document.createElement('div');
        header.className = 'section-header';
        
        if (isComplete) {
            header.classList.add('completed');
        }
        
        header.innerHTML = `
            <span class="section-title">
                ${sectionName}
                ${progressHTML}
            </span>
            <span class="section-arrow">▶</span>
        `;

        const videoListDiv = document.createElement('div');
        videoListDiv.className = 'video-list';

        sectionData.videos.forEach(video => {
            const videoItem = document.createElement('div');
            videoItem.className = 'video-item';
            videoItem.dataset.section = sectionName;
            videoItem.dataset.path = video.path;
            
            if (watchedVideos.includes(video.path)) {
                videoItem.classList.add('watched');
            }
            
            const videoName = document.createElement('span');
            videoName.className = 'video-name';
            videoName.textContent = video.name;
            
            const checkmark = document.createElement('div');
            checkmark.className = 'video-checkmark';
            checkmark.textContent = watchedVideos.includes(video.path) ? '✓' : '';
            checkmark.title = 'Toggle watched status';
            
            checkmark.addEventListener('click', (e) => {
                e.stopPropagation();
                toggleWatched(video.path);
            });
            
            videoName.addEventListener('click', () => {
                loadVideo(sectionName, video);
            });
            
            videoItem.appendChild(videoName);
            videoItem.appendChild(checkmark);
            videoListDiv.appendChild(videoItem);
        });

        header.addEventListener('click', () => {
            section.classList.toggle('expanded');
        });

        section.appendChild(header);
        section.appendChild(videoListDiv);
        sectionsContainer.appendChild(section);
    });

    if (sectionsContainer.firstChild) {
        sectionsContainer.firstChild.classList.add('expanded');
    }
}

// Update course statistics
function updateStats() {
    const videoCount = videoList.length;
    const watchedCount = watchedVideos.length;
    const percentage = videoCount > 0 ? Math.round((watchedCount / videoCount) * 100) : 0;
    
    const globalProgress = document.getElementById('global-progress');
    if (globalProgress) {
        globalProgress.textContent = `${percentage}% Complete`;
    }
}

// Load and play video
function loadVideo(sectionName, video) {
    currentSection = sectionName;
    currentVideo = video;

    loadingSpinner.classList.add('show');

    welcomeScreen.style.display = 'none';
    videoPlayer.style.display = 'block';
    videoInfo.style.display = 'block';
    videoControls.style.display = 'block';

    videoPlayer.src = encodeURI(video.path);

    if (video.subtitle) {
        subtitleTrack.src = encodeURI(video.subtitle);
        ccBtn.style.opacity = '0.9';
        
        for (let i = 0; i < videoPlayer.textTracks.length; i++) {
            videoPlayer.textTracks[i].mode = 'disabled';
        }
        
        if (subtitlesEnabled) {
            videoPlayer.textTracks[0].mode = 'hidden';
        } else {
            videoPlayer.textTracks[0].mode = 'disabled';
        }
    } else {
        subtitleTrack.src = '';
        ccBtn.style.opacity = '0.5';
        
        for (let i = 0; i < videoPlayer.textTracks.length; i++) {
            videoPlayer.textTracks[i].mode = 'disabled';
        }
        
        ccBtn.style.color = 'white';
        ccToggle.classList.remove('active');
        subtitleOverlay.style.display = 'none';
    }

    videoPlayer.load();

    videoTitle.textContent = video.name;
    videoSection.textContent = `Section: ${sectionName}`;

    loadResources(video);
    updateSidebarHighlight();
    updateNavigationButtons();
}

// Update sidebar to highlight current video
function updateSidebarHighlight() {
    document.querySelectorAll('.video-item').forEach(item => {
        item.classList.remove('active');
    });

    document.querySelectorAll('.section-header').forEach(header => {
        header.classList.remove('active');
    });

    if (currentVideo) {
        const activeItem = document.querySelector(
            `.video-item[data-path="${currentVideo.path}"]`
        );
        if (activeItem) {
            activeItem.classList.add('active');

            const section = activeItem.closest('.section');
            if (section) {
                section.classList.add('expanded');
                section.querySelector('.section-header').classList.add('active');
            }

            activeItem.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
        }
    }
}

// Update navigation buttons state
function updateNavigationButtons() {
    const currentIndex = videoList.findIndex(
        item => item.video.path === currentVideo?.path
    );

    prevBtn.disabled = currentIndex <= 0;
    nextBtn.disabled = currentIndex >= videoList.length - 1;
}

// Load and display resources for current video
function loadResources(video) {
    resourcesPanel.classList.remove('show');

    if (video.resources && video.resources.length > 0) {
        resourcesBtn.disabled = false;
        resourcesBtn.style.opacity = '1';

        resourcesList.innerHTML = '';
        video.resources.forEach(resource => {
            const resourceItem = document.createElement('div');
            resourceItem.className = 'resource-item';

            const link = document.createElement('a');
            link.href = encodeURI(resource.path);
            link.target = '_blank';
            link.innerHTML = `
                <span class="resource-icon">📄</span>
                <span>${resource.name}</span>
            `;

            resourceItem.appendChild(link);
            resourcesList.appendChild(resourceItem);
        });
    } else {
        resourcesBtn.disabled = true;
        resourcesBtn.style.opacity = '0.5';
        resourcesList.innerHTML = '<div class="resources-empty">No resources available for this video</div>';
    }
}

// Toggle resources panel visibility
function toggleResources() {
    resourcesPanel.classList.toggle('show');
}

// Toggle play/pause
function togglePlayPause() {
    if (videoPlayer.paused) {
        videoPlayer.play();
    } else {
        videoPlayer.pause();
    }
}

// Navigate to previous video
function playPrevious() {
    const currentIndex = videoList.findIndex(
        item => item.video.path === currentVideo?.path
    );
    if (currentIndex > 0) {
        const prev = videoList[currentIndex - 1];
        loadVideo(prev.section, prev.video);
    }
}

// Navigate to next video
function playNext() {
    const currentIndex = videoList.findIndex(
        item => item.video.path === currentVideo?.path
    );
    if (currentIndex < videoList.length - 1) {
        const next = videoList[currentIndex + 1];
        loadVideo(next.section, next.video);
    }
}

// Toggle mute
function toggleMute() {
    videoPlayer.muted = !videoPlayer.muted;
    updateVolumeIcon();
}

// Update volume icon
function updateVolumeIcon() {
    if (videoPlayer.muted || videoPlayer.volume === 0) {
        volumeIcon.style.display = 'none';
        muteIcon.style.display = 'block';
    } else {
        volumeIcon.style.display = 'block';
        muteIcon.style.display = 'none';
    }
}

// Change playback speed
function changeSpeed(speed) {
    videoPlayer.playbackRate = speed;
    showSpeedToast(speed);

    document.querySelectorAll('.speed-option').forEach(item => {
        item.classList.remove('active');
        if (parseFloat(item.dataset.speed) === speed) {
            item.classList.add('active');
        }
    });
    
    const currentSpeedVal = document.getElementById('current-speed-val');
    if (currentSpeedVal) {
        currentSpeedVal.textContent = speed === 1 ? 'Normal' : speed + 'x';
    }
}

// Apply all subtitle styles dynamically (size, font color, font opacity, bg color, bg opacity, edge styles)
function applySubtitleStyles() {
    if (!subtitleOverlay) return;

    // Font color and opacity
    const fontRgb = subtitleColorMap[subtitleFontColor] || [255, 255, 255];
    const fontOpacity = parseFloat(subtitleFontOpacity) / 100;
    subtitleOverlay.style.color = `rgba(${fontRgb[0]}, ${fontRgb[1]}, ${fontRgb[2]}, ${fontOpacity})`;

    // Background color and opacity
    const bgRgb = subtitleColorMap[subtitleBgColor] || [0, 0, 0];
    const bgOpacity = parseFloat(subtitleBgOpacity) / 100;
    subtitleOverlay.style.backgroundColor = `rgba(${bgRgb[0]}, ${bgRgb[1]}, ${bgRgb[2]}, ${bgOpacity})`;

    // Subtitle font size variable
    document.documentElement.style.setProperty('--subtitle-size', subtitleSize);

    // Character edge styles text-shadows
    const outlineColor = subtitleFontColor === 'Black' ? '#ffffff' : '#000000';
    const raisedHighlight = subtitleFontColor === 'Black' ? 'rgba(255, 255, 255, 0.6)' : 'rgba(255, 255, 255, 0.8)';
    const depressedHighlight = subtitleFontColor === 'Black' ? 'rgba(255, 255, 255, 0.4)' : 'rgba(255, 255, 255, 0.6)';
    const shadowColor = subtitleFontColor === 'Black' ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.9)';

    let shadowStyle = 'none';
    if (subtitleEdgeStyle === 'Drop Shadow') {
        shadowStyle = `2px 2px 3px ${shadowColor}`;
    } else if (subtitleEdgeStyle === 'Raised') {
        shadowStyle = `-1px -1px 0 rgba(0,0,0,0.8), 1px 1px 0 ${raisedHighlight}, 1px 1px 2px rgba(0,0,0,0.8)`;
    } else if (subtitleEdgeStyle === 'Depressed') {
        shadowStyle = `1px 1px 0 ${depressedHighlight}, -1px -1px 0 rgba(0,0,0,0.8), -1px -1px 2px rgba(0,0,0,0.8)`;
    } else if (subtitleEdgeStyle === 'Outline') {
        shadowStyle = `-1px -1px 0 ${outlineColor}, 1px -1px 0 ${outlineColor}, -1px 1px 0 ${outlineColor}, 1px 1px 0 ${outlineColor}, 0 -1px 0 ${outlineColor}, 0 1px 0 ${outlineColor}, -1px 0 0 ${outlineColor}, 1px 0 0 ${outlineColor}`;
    }
    subtitleOverlay.style.textShadow = shadowStyle;
}

// Set subtitle size
function setSubtitleSize(size) {
    subtitleSize = size;
    localStorage.setItem('subtitleSize', size);
    
    document.querySelectorAll('.size-option').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.size === size) {
            item.classList.add('active');
        }
    });
    
    const currentSizeVal = document.getElementById('current-size-val');
    if (currentSizeVal) {
        currentSizeVal.textContent = size;
    }
    applySubtitleStyles();
}

// Set subtitle font color
function setSubtitleFontColor(color) {
    subtitleFontColor = color;
    localStorage.setItem('subtitleFontColor', color);
    
    document.querySelectorAll('.font-color-option').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.color === color) {
            item.classList.add('active');
        }
    });
    
    const currentVal = document.getElementById('current-font-color-val');
    if (currentVal) {
        currentVal.textContent = color;
    }
    applySubtitleStyles();
}

// Set subtitle font opacity
function setSubtitleFontOpacity(opacity) {
    subtitleFontOpacity = opacity;
    localStorage.setItem('subtitleFontOpacity', opacity);
    
    document.querySelectorAll('.font-opacity-option').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.opacity === opacity) {
            item.classList.add('active');
        }
    });
    
    const currentVal = document.getElementById('current-font-opacity-val');
    if (currentVal) {
        currentVal.textContent = opacity;
    }
    applySubtitleStyles();
}

// Set subtitle background color
function setSubtitleBgColor(color) {
    subtitleBgColor = color;
    localStorage.setItem('subtitleBgColor', color);
    
    document.querySelectorAll('.bg-color-option').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.color === color) {
            item.classList.add('active');
        }
    });
    
    const currentVal = document.getElementById('current-bg-color-val');
    if (currentVal) {
        currentVal.textContent = color;
    }
    applySubtitleStyles();
}

// Set subtitle background opacity
function setSubtitleBgOpacity(opacity) {
    subtitleBgOpacity = opacity;
    localStorage.setItem('subtitleBgOpacity', opacity);
    
    document.querySelectorAll('.bg-opacity-option').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.opacity === opacity) {
            item.classList.add('active');
        }
    });
    
    const currentVal = document.getElementById('current-bg-opacity-val');
    if (currentVal) {
        currentVal.textContent = opacity;
    }
    applySubtitleStyles();
}

// Set subtitle character edge style
function setSubtitleEdgeStyle(style) {
    subtitleEdgeStyle = style;
    localStorage.setItem('subtitleEdgeStyle', style);
    
    document.querySelectorAll('.edge-style-option').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.style === style) {
            item.classList.add('active');
        }
    });
    
    const currentVal = document.getElementById('current-edge-style-val');
    if (currentVal) {
        currentVal.textContent = style;
    }
    applySubtitleStyles();
}

// Reset settings menu to main
function resetSettingsMenu() {
    document.getElementById('settings-main-menu').style.display = 'block';
    document.getElementById('settings-speed-menu').style.display = 'none';
    document.getElementById('settings-subtitle-menu').style.display = 'none';
    document.getElementById('settings-size-menu').style.display = 'none';
    document.getElementById('settings-font-color-menu').style.display = 'none';
    document.getElementById('settings-font-opacity-menu').style.display = 'none';
    document.getElementById('settings-bg-color-menu').style.display = 'none';
    document.getElementById('settings-bg-opacity-menu').style.display = 'none';
    document.getElementById('settings-edge-style-menu').style.display = 'none';
}

// Show speed change notification
function showSpeedToast(speed) {
    speedToast.textContent = `Speed: ${speed}x`;
    speedToast.classList.add('show');
    setTimeout(() => {
        speedToast.classList.remove('show');
    }, 1000);
}

// Toggle fullscreen
function toggleFullscreen() {
    if (!isFullscreen) {
        if (videoContainer.requestFullscreen) {
            videoContainer.requestFullscreen();
        } else if (videoContainer.webkitRequestFullscreen) {
            videoContainer.webkitRequestFullscreen();
        } else if (videoContainer.mozRequestFullScreen) {
            videoContainer.mozRequestFullScreen();
        } else if (videoContainer.msRequestFullscreen) {
            videoContainer.msRequestFullscreen();
        }
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}

// Show controls and reset inactivity timer
function showControlsAndResetTimer() {
    if (isFullscreen) {
        videoControls.classList.add('always-show');
        videoContainer.classList.remove('hide-cursor');
        isControlsVisible = true;

        if (inactivityTimer) {
            clearTimeout(inactivityTimer);
        }

        inactivityTimer = setTimeout(() => {
            if (isFullscreen && !videoPlayer.paused) {
                videoControls.classList.remove('always-show');
                videoContainer.classList.add('hide-cursor');
                isControlsVisible = false;
            }
        }, 3000);
    }
}

// Hide controls immediately
function hideControls() {
    if (isFullscreen && !videoPlayer.paused) {
        videoControls.classList.remove('always-show');
        videoContainer.classList.add('hide-cursor');
        isControlsVisible = false;
        if (inactivityTimer) {
            clearTimeout(inactivityTimer);
        }
    }
}

// Update custom subtitle overlay content
function updateSubtitles() {
    const track = videoPlayer.textTracks[0];
    if (!track || !subtitlesEnabled || !subtitleTrack.src) {
        subtitleOverlay.style.display = 'none';
        return;
    }
    
    const activeCues = track.activeCues;
    if (activeCues && activeCues.length > 0) {
        const latestCue = activeCues[activeCues.length - 1];
        subtitleOverlay.innerHTML = latestCue.text.replace(/\n/g, '<br>');
        subtitleOverlay.style.display = 'block';
    } else {
        subtitleOverlay.style.display = 'none';
    }
}

// Toggle subtitles
function toggleSubtitles() {
    const track = videoPlayer.textTracks[0];
    if (!subtitleTrack.src) {
        alert('No subtitles loaded. Please load a subtitle file first.');
        ccDropdown.classList.remove('show');
        return;
    }

    if (!subtitlesEnabled) {
        subtitlesEnabled = true;
        
        for (let i = 0; i < videoPlayer.textTracks.length; i++) {
            videoPlayer.textTracks[i].mode = 'disabled';
        }
        
        track.mode = 'hidden';
        ccBtn.style.color = '#4fc3f7';
        ccToggle.classList.add('active');
    } else {
        subtitlesEnabled = false;
        track.mode = 'disabled';
        ccBtn.style.color = 'white';
        ccToggle.classList.remove('active');
    }
    updateSubtitles();
}

// Convert SRT content to VTT format
function srtToVtt(srtContent) {
    let vttContent = 'WEBVTT\n\n';
    vttContent += srtContent.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, '$1.$2');
    return vttContent;
}

// Load custom subtitle file
function loadSubtitleFile(file) {
    const reader = new FileReader();

    reader.onload = function(e) {
        let content = e.target.result;
        const fileName = file.name.toLowerCase();

        if (fileName.endsWith('.srt')) {
            content = srtToVtt(content);
        }

        const blob = new Blob([content], { type: 'text/vtt' });
        const blobUrl = URL.createObjectURL(blob);

        subtitleTrack.src = blobUrl;
        ccBtn.style.opacity = '0.9';

        subtitlesEnabled = true;
        
        for (let i = 0; i < videoPlayer.textTracks.length; i++) {
            videoPlayer.textTracks[i].mode = 'disabled';
        }
        
        videoPlayer.textTracks[0].mode = 'hidden';
        ccBtn.style.color = '#4fc3f7';
        ccToggle.classList.add('active');
        updateSubtitles();

        ccDropdown.classList.remove('show');
        console.log('Subtitle loaded successfully:', file.name);
    };

    reader.onerror = function() {
        console.error('Error reading subtitle file');
        alert('Failed to load subtitle file. Please try again.');
    };

    reader.readAsText(file);
}

// Format time (seconds to MM:SS or HH:MM:SS)
function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';

    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);

    if (h > 0) {
        return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m}:${s.toString().padStart(2, '0')}`;
}

// Update progress bar
function updateProgress() {
    if (!isDraggingProgress) {
        const percent = (videoPlayer.currentTime / videoPlayer.duration) * 100;
        progressBar.style.width = percent + '%';
    }
    timeDisplay.textContent = `${formatTime(videoPlayer.currentTime)} / ${formatTime(videoPlayer.duration)}`;
}

// Seek video
function seekVideo(e) {
    const rect = progressContainer.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    const time = percent * videoPlayer.duration;
    videoPlayer.currentTime = time;
    progressBar.style.width = (percent * 100) + '%';
}

// Show time tooltip on progress bar hover
function showProgressTooltip(e) {
    const rect = progressContainer.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    const time = percent * videoPlayer.duration;
    progressTooltip.textContent = formatTime(time);
    progressTooltip.style.left = (e.clientX - rect.left) + 'px';
}

// Setup all event listeners
function setupEventListeners() {
    // Video player events
    videoPlayer.addEventListener('play', () => {
        playIcon.style.display = 'none';
        pauseIcon.style.display = 'block';
        if (isFullscreen) {
            showControlsAndResetTimer();
        }
    });

    videoPlayer.addEventListener('pause', () => {
        playIcon.style.display = 'block';
        pauseIcon.style.display = 'none';
        if (isFullscreen) {
            videoControls.classList.add('always-show');
            videoContainer.classList.remove('hide-cursor');
            if (inactivityTimer) {
                clearTimeout(inactivityTimer);
            }
        }
    });

    videoPlayer.addEventListener('timeupdate', () => {
        updateProgress();
        updateSubtitles();
    });

    videoPlayer.addEventListener('ended', () => {
        if (currentVideo) {
            markAsWatched(currentVideo.path);
        }
        playNext();
    });

    videoPlayer.addEventListener('loadedmetadata', () => {
        loadingSpinner.classList.remove('show');
        videoPlayer.play();
    });

    videoPlayer.addEventListener('volumechange', updateVolumeIcon);

    videoContainer.addEventListener('click', (e) => {
        if (e.target === videoPlayer || e.target === videoContainer) {
            togglePlayPause();
        }
    });

    videoContainer.addEventListener('dblclick', (e) => {
        if (e.target === videoPlayer || e.target === videoContainer) {
            toggleFullscreen();
        }
    });

    playPauseBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        togglePlayPause();
    });

    prevBtn.addEventListener('click', playPrevious);
    nextBtn.addEventListener('click', () => {
        if (currentVideo) {
            markAsWatched(currentVideo.path);
        }
        playNext();
    });

    volumeBtn.addEventListener('click', toggleMute);

    volumeSlider.addEventListener('input', (e) => {
        videoPlayer.volume = e.target.value / 100;
        videoPlayer.muted = false;
    });

    ccBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        ccDropdown.classList.toggle('show');
        settingsDropdown.classList.remove('show');
    });

    ccToggle.addEventListener('click', () => {
        toggleSubtitles();
        ccDropdown.classList.remove('show');
    });

    ccLoad.addEventListener('click', () => {
        subtitleFileInput.click();
    });

    subtitleFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            loadSubtitleFile(file);
        }
        e.target.value = '';
    });

    settingsBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isShowing = settingsDropdown.classList.contains('show');
        if (!isShowing) {
            resetSettingsMenu();
        }
        settingsDropdown.classList.toggle('show');
        ccDropdown.classList.remove('show');
    });

    const speedMenuBtn = document.getElementById('settings-speed-menu-btn');
    const subtitlesMenuBtn = document.getElementById('settings-subtitles-menu-btn');
    const sizeMenuBtn = document.getElementById('settings-size-menu-btn');
    const fontColorMenuBtn = document.getElementById('settings-font-color-menu-btn');
    const fontOpacityMenuBtn = document.getElementById('settings-font-opacity-menu-btn');
    const bgColorMenuBtn = document.getElementById('settings-bg-color-menu-btn');
    const bgOpacityMenuBtn = document.getElementById('settings-bg-opacity-menu-btn');
    const edgeStyleMenuBtn = document.getElementById('settings-edge-style-menu-btn');

    const speedBackBtn = document.getElementById('speed-back-btn');
    const subtitleBackBtn = document.getElementById('subtitle-back-btn');
    const sizeBackBtn = document.getElementById('size-back-btn');
    const fontColorBackBtn = document.getElementById('font-color-back-btn');
    const fontOpacityBackBtn = document.getElementById('font-opacity-back-btn');
    const bgColorBackBtn = document.getElementById('bg-color-back-btn');
    const bgOpacityBackBtn = document.getElementById('bg-opacity-back-btn');
    const edgeStyleBackBtn = document.getElementById('edge-style-back-btn');

    // Menu Navigation handlers
    speedMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-main-menu').style.display = 'none';
        document.getElementById('settings-speed-menu').style.display = 'block';
    });

    subtitlesMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-main-menu').style.display = 'none';
        document.getElementById('settings-subtitle-menu').style.display = 'block';
    });

    sizeMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-subtitle-menu').style.display = 'none';
        document.getElementById('settings-size-menu').style.display = 'block';
    });

    fontColorMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-subtitle-menu').style.display = 'none';
        document.getElementById('settings-font-color-menu').style.display = 'block';
    });

    fontOpacityMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-subtitle-menu').style.display = 'none';
        document.getElementById('settings-font-opacity-menu').style.display = 'block';
    });

    bgColorMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-subtitle-menu').style.display = 'none';
        document.getElementById('settings-bg-color-menu').style.display = 'block';
    });

    bgOpacityMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-subtitle-menu').style.display = 'none';
        document.getElementById('settings-bg-opacity-menu').style.display = 'block';
    });

    edgeStyleMenuBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-subtitle-menu').style.display = 'none';
        document.getElementById('settings-edge-style-menu').style.display = 'block';
    });

    // Back Button handlers
    speedBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-speed-menu').style.display = 'none';
        document.getElementById('settings-main-menu').style.display = 'block';
    });

    subtitleBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-subtitle-menu').style.display = 'none';
        document.getElementById('settings-main-menu').style.display = 'block';
    });

    sizeBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-size-menu').style.display = 'none';
        document.getElementById('settings-subtitle-menu').style.display = 'block';
    });

    fontColorBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-font-color-menu').style.display = 'none';
        document.getElementById('settings-subtitle-menu').style.display = 'block';
    });

    fontOpacityBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-font-opacity-menu').style.display = 'none';
        document.getElementById('settings-subtitle-menu').style.display = 'block';
    });

    bgColorBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-bg-color-menu').style.display = 'none';
        document.getElementById('settings-subtitle-menu').style.display = 'block';
    });

    bgOpacityBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-bg-opacity-menu').style.display = 'none';
        document.getElementById('settings-subtitle-menu').style.display = 'block';
    });

    edgeStyleBackBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.getElementById('settings-edge-style-menu').style.display = 'none';
        document.getElementById('settings-subtitle-menu').style.display = 'block';
    });

    // Option selections
    document.querySelectorAll('.speed-option').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const speed = parseFloat(item.dataset.speed);
            changeSpeed(speed);
            settingsDropdown.classList.remove('show');
        });
    });

    document.querySelectorAll('.size-option').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const size = item.dataset.size;
            setSubtitleSize(size);
            settingsDropdown.classList.remove('show');
        });
    });

    document.querySelectorAll('.font-color-option').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const color = item.dataset.color;
            setSubtitleFontColor(color);
            settingsDropdown.classList.remove('show');
        });
    });

    document.querySelectorAll('.font-opacity-option').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const opacity = item.dataset.opacity;
            setSubtitleFontOpacity(opacity);
            settingsDropdown.classList.remove('show');
        });
    });

    document.querySelectorAll('.bg-color-option').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const color = item.dataset.color;
            setSubtitleBgColor(color);
            settingsDropdown.classList.remove('show');
        });
    });

    document.querySelectorAll('.bg-opacity-option').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const opacity = item.dataset.opacity;
            setSubtitleBgOpacity(opacity);
            settingsDropdown.classList.remove('show');
        });
    });

    document.querySelectorAll('.edge-style-option').forEach(item => {
        item.addEventListener('click', (e) => {
            e.stopPropagation();
            const style = item.dataset.style;
            setSubtitleEdgeStyle(style);
            settingsDropdown.classList.remove('show');
        });
    });

    document.addEventListener('click', (e) => {
        if (!settingsBtn.contains(e.target) && !settingsDropdown.contains(e.target)) {
            settingsDropdown.classList.remove('show');
        }
        if (!ccBtn.contains(e.target) && !ccDropdown.contains(e.target)) {
            ccDropdown.classList.remove('show');
        }
    });

    fullscreenBtn.addEventListener('click', toggleFullscreen);

    document.addEventListener('fullscreenchange', () => {
        isFullscreen = !!document.fullscreenElement;
        updateFullscreenIcon();
        if (isFullscreen) {
            showControlsAndResetTimer();
        } else {
            if (inactivityTimer) {
                clearTimeout(inactivityTimer);
            }
            videoControls.classList.remove('always-show');
            videoContainer.classList.remove('hide-cursor');
        }
    });

    document.addEventListener('webkitfullscreenchange', () => {
        isFullscreen = !!document.webkitFullscreenElement;
        updateFullscreenIcon();
        if (isFullscreen) {
            showControlsAndResetTimer();
        } else {
            if (inactivityTimer) {
                clearTimeout(inactivityTimer);
            }
            videoControls.classList.remove('always-show');
            videoContainer.classList.remove('hide-cursor');
        }
    });

    videoContainer.addEventListener('mousemove', () => {
        if (isFullscreen) {
            showControlsAndResetTimer();
        }
    });

    videoPlayer.addEventListener('pause', () => {
        if (isFullscreen) {
            videoControls.classList.add('always-show');
            videoContainer.classList.remove('hide-cursor');
            if (inactivityTimer) {
                clearTimeout(inactivityTimer);
            }
        }
    });

    videoPlayer.addEventListener('play', () => {
        if (isFullscreen) {
            showControlsAndResetTimer();
        }
    });

    progressContainer.addEventListener('click', seekVideo);

    progressContainer.addEventListener('mousedown', (e) => {
        isDraggingProgress = true;
        seekVideo(e);
    });

    document.addEventListener('mousemove', (e) => {
        if (isDraggingProgress) {
            seekVideo(e);
        }
    });

    document.addEventListener('mouseup', () => {
        isDraggingProgress = false;
    });

    progressContainer.addEventListener('mousemove', showProgressTooltip);

    resourcesBtn.addEventListener('click', toggleResources);
    resetProgressBtn.addEventListener('click', resetProgress);

    resizer.addEventListener('mousedown', (e) => {
        isResizing = true;
        startX = e.clientX;
        startWidth = sidebar.offsetWidth;
        document.body.classList.add('resizing');
        e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
        if (!isResizing) return;
        const delta = e.clientX - startX;
        const newWidth = startWidth + delta;
        if (newWidth >= 200 && newWidth <= 600) {
            sidebar.style.width = newWidth + 'px';
        }
    });

    document.addEventListener('mouseup', () => {
        if (isResizing) {
            isResizing = false;
            document.body.classList.remove('resizing');
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') {
            return;
        }

        switch(e.key.toLowerCase()) {
            case ' ':
                e.preventDefault();
                togglePlayPause();
                break;
            case '[':
                e.preventDefault();
                const newSlowSpeed = Math.max(0.25, videoPlayer.playbackRate - 0.25);
                changeSpeed(newSlowSpeed);
                break;
            case ']':
                e.preventDefault();
                const newFastSpeed = Math.min(2, videoPlayer.playbackRate + 0.25);
                changeSpeed(newFastSpeed);
                break;
            case 'arrowleft':
                e.preventDefault();
                videoPlayer.currentTime = Math.max(0, videoPlayer.currentTime - 5);
                break;
            case 'arrowright':
                e.preventDefault();
                videoPlayer.currentTime = Math.min(
                    videoPlayer.duration,
                    videoPlayer.currentTime + 5
                );
                break;
            case 'f':
                e.preventDefault();
                toggleFullscreen();
                break;
            case 'm':
                e.preventDefault();
                toggleMute();
                break;
            case 'c':
                e.preventDefault();
                ccDropdown.classList.toggle('show');
                settingsDropdown.classList.remove('show');
                break;
        }
    });

    const track = videoPlayer.textTracks[0];
    if (track) {
        track.addEventListener('cuechange', updateSubtitles);
    }
}

// Update fullscreen icon
function updateFullscreenIcon() {
    if (isFullscreen) {
        fullscreenIcon.style.display = 'none';
        fullscreenExitIcon.style.display = 'block';
        videoContainer.classList.add('fullscreen');
    } else {
        fullscreenIcon.style.display = 'block';
        fullscreenExitIcon.style.display = 'none';
        videoContainer.classList.remove('fullscreen');
    }
}

// Initialize on page load
async function init() {
    try {
        const structRes = await fetch('/api/course_structure');
        const structData = await structRes.json();
        
        courseData = structData.structure;
        const courseName = structData.course_name;
        
        document.title = `${courseName} - Course Player`;
        document.getElementById('course-title').textContent = `📚 ${courseName}`;
        document.getElementById('welcome-course-title').textContent = `Welcome to ${courseName}`;
        
        const progressRes = await fetch('/api/progress');
        watchedVideos = await progressRes.json();
        
        buildVideoList();
        renderSidebar();
        updateStats();
        setupEventListeners();
        setSubtitleSize(subtitleSize);
        setSubtitleFontColor(subtitleFontColor);
        setSubtitleFontOpacity(subtitleFontOpacity);
        setSubtitleBgColor(subtitleBgColor);
        setSubtitleBgOpacity(subtitleBgOpacity);
        setSubtitleEdgeStyle(subtitleEdgeStyle);
    } catch (error) {
        console.error('Failed to initialize Course Player:', error);
    }
}

init();
